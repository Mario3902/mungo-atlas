import { NextResponse } from "next/server"
import { getCollection } from "@/lib/database"

export async function GET() {
  try {
    const collection = await getCollection("applications")

    // Use MongoDB aggregation to get counts
    const stats = await collection.aggregate([
      {
        $group: {
          _id: null,
          total: { $sum: 1 },
          pending: {
            $sum: {
              $cond: [{ $eq: ["$status", "pendente"] }, 1, 0]
            }
          },
          approved: {
            $sum: {
              $cond: [{ $eq: ["$status", "aprovado"] }, 1, 0]
            }
          },
          rejected: {
            $sum: {
              $cond: [{ $eq: ["$status", "rejeitado"] }, 1, 0]
            }
          },
          analysis: {
            $sum: {
              $cond: [{ $eq: ["$status", "em-analise"] }, 1, 0]
            }
          }
        }
      }
    ]).toArray()

    const result = stats.length > 0 ? stats[0] : {
      total: 0,
      pending: 0,
      approved: 0,
      rejected: 0,
      analysis: 0
    }

    // Remove the _id field from the result
    delete result._id

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error fetching stats:", error)
    return NextResponse.json({
      total: 0,
      pending: 0,
      approved: 0,
      rejected: 0,
      analysis: 0,
    })
  }
}

