import { type NextRequest, NextResponse } from "next/server"
import { findOne, findMany, updateOne } from "@/lib/database"
import { ObjectId } from "mongodb"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    
    // Validate ObjectId format
    if (!ObjectId.isValid(id)) {
      return NextResponse.json({ error: "ID inválido" }, { status: 400 })
    }

    const application = await findOne("applications", { _id: new ObjectId(id) })

    if (!application) {
      return NextResponse.json({ error: "Candidatura não encontrada" }, { status: 404 })
    }

    // Get documents for this application
    const documents = await findMany("documents", { application_id: id })

    const applicationWithDocuments = {
      ...application,
      documents,
    }

    return NextResponse.json(applicationWithDocuments)
  } catch (error) {
    console.error("Error fetching application:", error)
    return NextResponse.json({ error: "Erro ao carregar candidatura" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const { status } = await request.json()

    // Validate ObjectId format
    if (!ObjectId.isValid(id)) {
      return NextResponse.json({ error: "ID inválido" }, { status: 400 })
    }

    const result = await updateOne(
      "applications", 
      { _id: new ObjectId(id) }, 
      { 
        $set: { 
          status: status, 
          updated_at: new Date() 
        } 
      }
    )

    if (result.matchedCount === 0) {
      return NextResponse.json({ error: "Candidatura não encontrada" }, { status: 404 })
    }

    return NextResponse.json({ message: "Status atualizado com sucesso" })
  } catch (error) {
    console.error("Error updating application:", error)
    return NextResponse.json({ error: "Erro ao atualizar status" }, { status: 500 })
  }
}

