import { type NextRequest, NextResponse } from "next/server"
import { findMany, insertOne } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search")
    const status = searchParams.get("status")
    const categoria = searchParams.get("categoria")

    // Build MongoDB filter
    let filter: any = {}

    if (search) {
      filter.$or = [
        { nome_completo: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { bilhete_identidade: { $regex: search, $options: 'i' } }
      ]
    }

    if (status && status !== "todos") {
      filter.status = status
    }

    if (categoria && categoria !== "all") {
      filter.categoria = categoria
    }

    // MongoDB options for sorting
    const options = {
      sort: { created_at: -1 }
    }

    const applications = await findMany("applications", filter, options)
    return NextResponse.json({ applications })
  } catch (error) {
    console.error("Error fetching applications:", error)
    return NextResponse.json({ applications: [] })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    const applicationData = {
      nome_completo: data.nome_completo,
      email: data.email,
      telefone: data.telefone,
      bilhete_identidade: data.bilhete_identidade,
      data_nascimento: data.data_nascimento,
      endereco: data.endereco,
      situacao_academica: data.situacao_academica,
      nome_escola: data.nome_escola,
      media_final: data.media_final,
      universidade: data.universidade,
      curso: data.curso,
      categoria: data.categoria,
      carta_motivacao: data.carta_motivacao,
      nome_encarregado: data.nome_encarregado,
      telefone_encarregado: data.telefone_encarregado,
      status: "pendente", // Default status
      created_at: new Date()
    }

    const result = await insertOne("applications", applicationData)

    return NextResponse.json({
      message: "Candidatura submetida com sucesso",
      applicationId: result.insertedId,
    })
  } catch (error) {
    console.error("Error creating application:", error)
    return NextResponse.json({ error: "Erro ao submeter candidatura" }, { status: 500 })
  }
}

