import { NextResponse } from "next/server"
import { getCollection } from "@/lib/database"

export async function GET() {
  try {
    const collection = await getCollection("applications")

    // Primeiro, tenta buscar candidatos aprovados
    let candidates = await collection.aggregate([
      { $match: { status: "aprovado" } },
      { $sample: { size: 1 } }
    ]).toArray()

    // Se não houver candidatos aprovados, busca entre todos os candidatos
    if (candidates.length === 0) {
      candidates = await collection.aggregate([
        { $sample: { size: 1 } }
      ]).toArray()
    }

    if (candidates.length === 0) {
      return NextResponse.json(
        {
          error: "Nenhum candidato disponível para sorteio",
        },
        { status: 404 },
      )
    }

    const candidate = candidates[0]

    // Log do sorteio para auditoria
    console.log(`Candidato sorteado: ${candidate.nome_completo} (ID: ${candidate._id}) em ${new Date().toISOString()}`)

    return NextResponse.json({
      candidate,
      message: "Candidato sorteado com sucesso",
    })
  } catch (error) {
    console.error("Erro no sorteio de candidato:", error)
    return NextResponse.json(
      {
        error: "Erro interno do servidor",
      },
      { status: 500 },
    )
  }
}

