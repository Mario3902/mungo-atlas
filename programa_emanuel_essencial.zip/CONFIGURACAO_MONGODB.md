# Configuração MongoDB Atlas - Bolsa de Estudos Emanuel Xirimbimbi

## Resumo das Alterações Realizadas

O projeto foi successfully configurado para usar MongoDB Atlas em vez de MySQL. As seguintes alterações foram implementadas:

### 1. Dependências Atualizadas
- **Removido**: `mysql2` 
- **Adicionado**: `mongodb` (driver oficial do MongoDB para Node.js)

### 2. Configuração de Banco de Dados
- Criado novo arquivo `lib/database.ts` com configurações MongoDB
- Adicionada string de conexão MongoDB Atlas no arquivo `.env`
- Implementadas funções helper para operações MongoDB comuns

### 3. APIs Atualizadas
Todos os endpoints da API foram convertidos de SQL para MongoDB:

#### `/api/applications/route.ts`
- **GET**: Busca candidaturas com filtros (search, status, categoria)
- **POST**: Cria nova candidatura

#### `/api/applications/[id]/route.ts`
- **GET**: Busca candidatura específica por ID
- **PUT**: Atualiza status da candidatura

#### `/api/stats/route.ts`
- **GET**: Retorna estatísticas usando agregação MongoDB

#### `/api/draw-candidate/route.ts`
- **GET**: Sorteia candidato usando `$sample` do MongoDB

### 4. Estrutura de Dados MongoDB

As coleções MongoDB equivalem às tabelas MySQL:

```javascript
// Coleção: applications
{
  _id: ObjectId,
  nome_completo: String,
  email: String,
  telefone: String,
  bilhete_identidade: String,
  data_nascimento: String,
  endereco: String,
  situacao_academica: String,
  nome_escola: String,
  media_final: Number,
  universidade: String,
  curso: String,
  categoria: String,
  carta_motivacao: String,
  nome_encarregado: String,
  telefone_encarregado: String,
  status: String, // "pendente", "aprovado", "rejeitado", "em-analise"
  created_at: Date,
  updated_at: Date
}

// Coleção: documents
{
  _id: ObjectId,
  application_id: String, // Referência ao _id da candidatura
  filename: String,
  path: String,
  uploaded_at: Date
}
```

## Variáveis de Ambiente

Arquivo `.env` configurado com:
```
MONGODB_URI=mongodb+srv://nlua28902:LZ4ikC3q3gtBVLNV@cluster0.r9pzybd.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0
DB_NAME=bolsa_estudos
PORT=5000
```

## Como Testar a Conexão

1. Acesse: `http://localhost:5000/api/stats`
2. Se retornar `{"total":0,"pending":0,"approved":0,"rejected":0,"analysis":0}`, a conexão está funcionando
3. Se houver erro, verifique os logs do console

## Próximos Passos

1. **Testar todas as funcionalidades**: Formulário de inscrição, listagem, estatísticas
2. **Migrar dados existentes**: Se houver dados no MySQL, criar script de migração
3. **Configurar índices**: Otimizar performance com índices MongoDB apropriados

## Comandos Úteis

```bash
# Instalar dependências
npm install

# Executar em desenvolvimento
PORT=5000 npm run dev

# Compilar projeto
npm run build

# Executar em produção
npm start
```

## Suporte

O projeto está tecnicamente pronto para MongoDB Atlas. Caso enfrente problemas de conectividade, verifique:
1. Credenciais e string de conexão no `.env`
2. Acesso à rede do MongoDB Atlas (IP Whitelist)
3. Logs do servidor para mensagens de erro específicas


