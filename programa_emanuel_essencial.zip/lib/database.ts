import { MongoClient, ServerApiVersion, Db, Collection } from 'mongodb';

const uri = process.env.MONGODB_URI || "mongodb://localhost:27017";
const dbName = process.env.DB_NAME || "bolsa_estudos";

// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  },
  // SSL/TLS configuration
  tls: true,
  tlsAllowInvalidCertificates: false,
  tlsAllowInvalidHostnames: false,
  // Connection timeout settings
  connectTimeoutMS: 30000,
  socketTimeoutMS: 30000,
  serverSelectionTimeoutMS: 30000,
  // Retry settings
  retryWrites: true,
  retryReads: true,
  maxPoolSize: 10,
  minPoolSize: 1,
});

let isConnected = false;

async function connectToDatabase() {
  if (!isConnected) {
    try {
      console.log("Attempting to connect to MongoDB Atlas...");
      await client.connect();
      await client.db("admin").command({ ping: 1 });
      console.log("Successfully connected to MongoDB Atlas!");
      isConnected = true;
    } catch (error) {
      console.error("Failed to connect to MongoDB Atlas:", error);
      isConnected = false;
      throw error;
    }
  }
  return client.db(dbName);
}

export async function getDatabase(): Promise<Db> {
  return await connectToDatabase();
}

export async function getCollection(collectionName: string): Promise<Collection> {
  const db = await getDatabase();
  return db.collection(collectionName);
}

// Helper function to execute MongoDB operations
export async function executeOperation<T>(
  collectionName: string,
  operation: (collection: Collection) => Promise<T>
): Promise<T> {
  try {
    const collection = await getCollection(collectionName);
    return await operation(collection);
  } catch (error) {
    console.error("Database operation error:", error);
    throw error;
  }
}

// Common database operations
export async function insertOne(collectionName: string, document: any) {
  return await executeOperation(collectionName, async (collection) => {
    return await collection.insertOne(document);
  });
}

export async function insertMany(collectionName: string, documents: any[]) {
  return await executeOperation(collectionName, async (collection) => {
    return await collection.insertMany(documents);
  });
}

export async function findOne(collectionName: string, filter: any = {}) {
  return await executeOperation(collectionName, async (collection) => {
    return await collection.findOne(filter);
  });
}

export async function findMany(collectionName: string, filter: any = {}, options: any = {}) {
  return await executeOperation(collectionName, async (collection) => {
    return await collection.find(filter, options).toArray();
  });
}

export async function updateOne(collectionName: string, filter: any, update: any, options: any = {}) {
  return await executeOperation(collectionName, async (collection) => {
    return await collection.updateOne(filter, update, options);
  });
}

export async function updateMany(collectionName: string, filter: any, update: any, options: any = {}) {
  return await executeOperation(collectionName, async (collection) => {
    return await collection.updateMany(filter, update, options);
  });
}

export async function deleteOne(collectionName: string, filter: any) {
  return await executeOperation(collectionName, async (collection) => {
    return await collection.deleteOne(filter);
  });
}

export async function deleteMany(collectionName: string, filter: any) {
  return await executeOperation(collectionName, async (collection) => {
    return await collection.deleteMany(filter);
  });
}

// Legacy function for backward compatibility (converts SQL-like queries to MongoDB operations)
export async function executeQuery(query: string, params: any[] = []) {
  console.warn("executeQuery is deprecated. Use MongoDB-specific operations instead.");
  
  // Basic SQL to MongoDB conversion for common operations
  const lowerQuery = query.toLowerCase().trim();
  
  if (lowerQuery.startsWith('select')) {
    // This is a very basic conversion - you'll need to implement proper SQL to MongoDB conversion
    // based on your specific queries
    throw new Error("SQL queries are not supported with MongoDB. Please use MongoDB operations.");
  } else if (lowerQuery.startsWith('insert')) {
    throw new Error("SQL queries are not supported with MongoDB. Please use insertOne or insertMany.");
  } else if (lowerQuery.startsWith('update')) {
    throw new Error("SQL queries are not supported with MongoDB. Please use updateOne or updateMany.");
  } else if (lowerQuery.startsWith('delete')) {
    throw new Error("SQL queries are not supported with MongoDB. Please use deleteOne or deleteMany.");
  }
  
  throw new Error("Unsupported query type for MongoDB conversion.");
}

// Close connection when needed
export async function closeConnection() {
  if (isConnected) {
    await client.close();
    isConnected = false;
    console.log("MongoDB connection closed.");
  }
}

// Test connection function
export async function testConnection() {
  try {
    await connectToDatabase();
    console.log("MongoDB connection test successful!");
    return true;
  } catch (error) {
    console.error("MongoDB connection test failed:", error);
    return false;
  }
}

